import React from 'react';


function Cart () {
    return (
       <div>
<p>корзина</p>
       </div>
    )
}

export default Cart


