export const setProducts  = (items) => ({
    type : 'SET_PRODUCTS',
    payload : items,
})

