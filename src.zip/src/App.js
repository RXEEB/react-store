import React from "react";
import './App.css';
import Header from "./components/Header/Header";
import Main from "./Pages/Main";
import axios from 'axios';

import { Route } from 'react-router-dom'
import Cart from "./Pages/Cart";

import {setProducts} from './redux/actions/products'
import { useSelector, useDispatch } from "react-redux";



function App() {
    const dispatch = useDispatch()
    const {items} = useSelector(({products, filters }) => {
        return{
            items: products.items,
            
            

        }
    })
    

    React.useEffect(() => {
        // fetch('http://localhost:3000/data.json').then((resp) => resp.json()).then(json =>{
        //     dispatch(setProducts(data))
        //     })
        // }, [])


        axios.get(`http://localhost:3000/data.json`).then(({ data }) => {
                      dispatch(setProducts(data))
                    })


    },[] )

    return (
        <div className='App'>
            <Header />
            <div className='content'>

                <Route path='/' render={() => <Main items={items} />} exact />
                <Route path='/cart' render={() => <Cart />} exact />

            </div>
        </div>
        
    )

console.log(items)
}



//  function App() {
//     // const [data, setData] = React.useState([])

//     // React.useEffect(() => {
//     //         fetch('http://localhost:3000/data.json').then((resp) => resp.json()).then(json =>{
//     //             setData(json.data)
//     //         })
//     //     }, [])

//     class App extends React.Component {

//         componentDidMount(){
//             fetch('http://localhost:3000/data.json').then((resp) => resp.json()).then(json =>{
//                 window.store.dispatch(setProductsActions(json.data))


//             })


//             // axios.get(`http://localhost:3000/data.json`)
//             // .then(({data}) => {
//             //     store.dispatch(setProducts(data))
//             // })


//         }
//         render(){
//             return(
//                 <div className='App'>
//             <Header/>
//             <div className='content'>

//             <Route path='/' render={() => <Main items={this.props.items}/> } exact />
//             <Route path='/cart' render={() => <Cart/> } exact />

//             </div>
//         </div>
//             )
//         }
//     }


// const mapStateToProps =  state => {
//     return{
//         items: state.products.items
//     }
// }
// const mapDispatchToProps = dispatch => {
//     return{
//         setProducts:  (items) => dispatch(setProductsActions(items)),
//     }

// }




export default App



